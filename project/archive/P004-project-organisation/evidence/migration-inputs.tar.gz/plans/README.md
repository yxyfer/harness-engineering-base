# Work index

**Product delivery:** [Quality-first roadmap](active/QUALITY_FIRST_HARNESS.md).
**Current handoff:** [TASK-016](../tasks/TASK-016-UI-QUALITY.md), human visual
acceptance pending. Step 14 is the next independent implementation option.

## Find what you need

| Need | Read |
| --- | --- |
| What is next and why? | [Active plans](active/README.md) |
| One bounded outcome and its acceptance | [Task index](../tasks/README.md) |
| One step's instructions | Selected guide linked from the roadmap |
| How is it built and why? | [Reviewer entry](../docs/README.md) |
| What was actually checked? | Report linked from the task or roadmap |
| Closed work | [Completed plans](completed/README.md) |
| Replaced direction | [Superseded plans](superseded/README.md) |
| Intentional compromises | [Technical debt](technical-debt.md) |

## Keep work readable

1. A plan states outcome, sequence, dependencies and next action.
2. A task states acceptance, implementation choice, risk and recovery.
3. Architecture and ADRs explain the durable system; reports record evidence.

Link between these records. Update state in place. Do not paste task details,
commands/results or chronological progress notes into the plan. Historical
reports retain their original scope; later evidence is linked explicitly.
Never mark human acceptance complete from an automated pass.

Create bounded work from the [plan](PLAN_TEMPLATE.md) and
[task](../tasks/TASK_TEMPLATE.md) templates. Close by moving the plan, updating
incoming links and indexes, and retaining its final evidence.
