# TASK-NNN: Outcome-oriented title

- **Status:** ready | active | blocked | partial | complete
- **Owner:** TBD
- **Plan:** Link to the coordinating plan, when applicable.
- **Evidence:** Link after the verification report exists.

## Outcome

State the observable change and why it is needed in one or two sentences.

## Acceptance criteria

- [ ] Observable success case.
- [ ] Material failure, permission or recovery case, where applicable.
- [ ] Required verification and durable context are updated.

## Reviewer brief

**Implementation:** Link affected entry points and the relevant architecture
flow. Explain the before/after behaviour and boundaries that change, or state
why architecture is unaffected. Label proposed, real and simulated behaviour.

**Choice:** Explain the key approach and meaningful alternative/trade-off.
Link an ADR for durable choices; keep local decisions here.

**Risk and operation:** State affected users/data/contracts, failure impact,
deployment and rollback/recovery. For a change without deployment, say why.
List unresolved questions or approvals only when they actually apply.

## Verification

Name the checks and expected observations before implementation. Afterwards,
link the report with actual commands, results and limits; do not copy test logs.
Keep incomplete criteria unchecked and identify the next action/blocker.

## Context and scope

Link only required docs, decisions and source entry points. State constraints
and non-goals. Remove unused prompts. Aim for one page for a bounded task.
