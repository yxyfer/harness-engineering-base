# Active plans

| Plan | Outcome | Next action |
| --- | --- | --- |
| [Quality-first harness](QUALITY_FIRST_HARNESS.md) | Reliable verification and application foundations | TASK-016 visual acceptance; Step 14 independently eligible |

Start from the [work index](../README.md). Each plan coordinates one outcome;
tasks hold delivery detail and evidence. Completed and superseded plans belong
in their own directories, with incoming links updated.
