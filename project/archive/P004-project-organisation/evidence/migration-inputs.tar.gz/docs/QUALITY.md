# Quality Context

Step 12 adds production Chromium user/recovery journeys with durable SQL
assertions, narrowly documented negative HTTP errors, disposable save/ownership
mutants and interruption cleanup checks. Native smoke-evidence reports preserve
browser collection in verify; no counts are inferred from shell success.
Step 13 adds native axe/keyboard/reflow, candidate/comparison and measured lab
budgets in the project-owned example. Approved baselines remain pending; the
full native report fails visibly rather than claiming visual acceptance.

Step 08 implements full/partial verify reports with typed per-control states,
native counts and artifact/input hashes. Zero collection, skips, retries,
missing/malformed evidence and unsupported controls block completeness. No
silent retry occurs. Static results stay aggregate; no underlying tool collection
is invented. [Evidence contract](../.harness/verification/README.md) documents
scope, adapter responsibility, timeout cleanup, redaction and stale validation.

## Applicability and readiness (Step 06)

`./harness doctor [TARGET]` reports selection reasons, required context and
prerequisite gaps. Exit 0 means ready to run controls, not verified. Missing
tools never remove controls. Python/TypeScript static and test delegation use
existing commands. Step 10 recognizes only a reviewed initial native Next.js
build/test/browser-smoke contract; missing contracts remain unsupported.
Other requested capabilities are unsupported until executable controls exist.
No browser engine or multi-package aggregator is introduced. Step 09 adds the
narrow [native security baseline](../.harness/security/README.md).

Step 10's project-owned Chromium suite runs against a real production build;
the engine delegates, never grades screenshots or invents browser case counts.
Vitest JUnit reports 25 application cases (14 server plus 11 domain/component);
Playwright independently reports 22 production/UI cases; four visual cases
require pending human acceptance. The nine-case independent UI subset is not
complete verification. See [app quality](../examples/nextjs-app/docs/QUALITY.md).
Accessibility conformance and field performance remain unverified.
Step 11 adds required native
direct-server
JUnit evidence for identity/tenant/storage boundaries before component tests;
missing/zero/failing native reports cannot pass these declared capabilities.
Root checks explicitly exclude
independent `examples/` packages from aggregation; invoke each package root.

For schema 2, review profiles/frameworks (`auto` or explicit lists), capabilities
and roots in the example side file. Keep existing command overrides and native
tool settings when merging. Only `roots = ["."]` is executable; nested package
manifests/workspaces block even without a declared aggregate. Paths reject
traversal and symlinks. Detection excludes managed machinery/runtime trees.

Schema 2 always requires AGENTS, PRODUCT, ARCHITECTURE, QUALITY and DECISIONS.
Browser UI adds DESIGN; persistence/jobs add DATA; identity, tenancy, uploads
and integrations add relevant DATA/SECURITY. Unknown capabilities require
SECURITY and fail unsupported. Explicit extra context remains required.
`readiness.fail_on_needs_input` now blocks unfinished required context when true;
false permits unfinished (not missing/unsafe) context. Presence is not prose QA.

Schema 1 without security.json preserves reviewed documents and warns that
security.mode was inert. Explicit side-file opt-in (or schema 2 local/ci) selects
required offline security and external test isolation. Off means no assurance.
Neither removes capability requirements or changes project-owned files.
Explicit profile lists now cannot silently suppress detected applicable controls;
review contradictions before proceeding. Step 07 removes optional static-tool
success. Native defaults require project-local tools; reviewed equivalent
commands retain precedence and coverage responsibility.

Status: current

## Quality bar

Harness commands must resolve deterministically, preserve project ownership,
fail with actionable messages, and report only evidence they actually ran. The
engineering baseline must remain concise, language-idiomatic, and executable
through project-owned tools.

## Verification matrix

| Risk or behaviour | Verification | Command or evidence | Required gate |
| --- | --- | --- | --- |
| Core logic | Automated test | `./harness test` | Yes |
| Harness contract | Independent automated suite | `./harness self-test` | For harness changes |
| Project conventions | Static checks | `./harness check` | Yes |
| Golden path | Smoke test | `./harness smoke` | Yes |
| Critical interface states | Visual and interaction QA | Project-specific | When applicable |

## Test strategy

Contract tests cover configuration, manifests, profile selection, exclusions,
and exit behaviour. Both fixture projects exercise static checks, automated
tests, and smoke paths. Changes to command behaviour require regression coverage;
documentation-only changes require link and consistency checks.

Work indexes, task reviewer briefs and architecture maps support human review.
Link/lint gates check document mechanics, not semantic map accuracy, necessity,
operational context or human understanding. Reviewers trace affected flows to
source and challenge choices; maps/briefs are maintained with implementation.

Step 02 regressions use disposable installed copies, real no-pip environments,
and real pytest collection. They cover failing/healthy app tests, mixed suites,
missing local runners, declared unittest, zero collection and independent
self-tests. Required pytest cases fail visibly if setup is missing; they do not
download dependencies or skip. [QH-02](../verification/QH-02.md) records evidence.

Step 03 regressions exercise installed disposable targets, supported shebangs,
pruned nested exclusions, spaced paths, symlink boundaries, policy failures and
single project command resolution. Tool-call recorders prove argv/scope routing;
they do not establish native tool correctness. Real installed native tools and
missing coverage are reported separately in [QH-03](../verification/QH-03.md).

## Core CI

Step 09 separates explicit advisory setup from isolated test phases. CI launches
contracts/fixtures/negative cases with a synthetic environment under external
macOS Seatbelt and adds a required offline security gate. Findings block;
errors/missing/stale data remain unavailable. Root policy includes authoring and
default locks. Known pytest advisories await compatibility review. Remote runs
remain unverified; protection settings unchanged.

Step 05 adds a pinned macOS GitHub Actions workflow and
[locked native CI setup](../.harness/ci/README.md). Its static phase requires
ShellCheck, shfmt, Markdownlint, Ruff and Pyright; the existing Node fixture runs
Prettier, ESLint and TypeScript. Both contract commands, fixture tests/smokes
and disposable negative controls run without model-based grading. Unique logs
retain failed attempts. [QH-05](../verification/QH-05.md) distinguishes local
evidence from unverified remote execution; no branch protection is configured.

## Known limitations

- Setup is explicit; format/check do not install. Missing required defaults fail.
  Reviewed commands are editable and must remain complete and non-mutating.
- Generic function-size analysis is Python-aware only. Other profiles rely on
  their project linters rather than fragile harness parsing.

## Release criteria

A phase is complete only when `./harness check`, `./harness test`, and relevant
fixture smoke paths pass and a verification report records exact evidence and
limitations.

Harness changes also require `./harness self-test`. Native overrides/scripts
need reviewed native report adapters for complete verify claims. Verify rejects
zero cases/skips/retries/invalid evidence but does not prove critical-case coverage.
Static defaults fail missing tools;
arbitrary reviewed commands retain their native coverage contract.
Steps 02–03 repair F1–F5; managed-file
ownership findings F6–F7 are repaired in Step 04.

Step 04 uses full disposable installations, a real no-pip environment and
synthetic project additions to prove health remains intact. Shipped edits/loss,
unsafe paths, JSON duplicates, inventory drift and symlink destinations fail.
Deterministic release generation includes exactly reviewed inputs and leaves
consumer files/metadata untouched. [QH-04](../verification/QH-04.md) records
before/after evidence and native coverage limits.

## Target quality policy agreed on 2026-10-01

The following is the intended policy from the [product vision](PRODUCT.md).
Current enforcement remains limited to the implementation described above and
the [audit findings](../verification/AUDIT_2026_10_01.md).

- Automated test execution and grading are entirely programmatic. No secondary
  AI calls, LLM reviewers, or model-based screenshot judgments are permitted in
  the verification pipeline.
- Application tests and harness self-tests are separate suites. Missing declared
  runners, uncollected required cases, missing evidence, or unknown scope must
  not produce a fully verified result.
- Test meaningful outcomes and negative cases at the actual boundary. Use
  disposable persistence for storage claims and direct server requests for
  authorization claims. Identify mocked external integrations explicitly.
- Use browser interaction assertions, automated accessibility rules, and pixel
  comparisons against deliberately approved baselines for measurable UI quality.
  Human product/design judgment is not represented as an automated pass.
- Coverage, mutation results, duplication, and source size are supporting
  evidence. No single percentage or composite score establishes quality.
- Gates select relevant language/framework/capability controls and explain their
  scope. Local partial runs are explicit; required CI suites remain complete.
- Record failed retries and reviewable exceptions. Do not silently disable a
  test, lower a threshold, update a baseline, or change the runner to pass.
- Bind reports to source, configuration, lockfiles, tools, and evidence. A later
  edit invalidates an earlier completion claim for affected behaviour.

The initial implementation milestone fixes the audit's false-success paths and
adds CI before expanding installation/update functionality.
