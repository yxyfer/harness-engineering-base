# Plan: Outcome-oriented title

- **Status:** proposed | active | blocked | complete | superseded
- **Owner:** TBD
- **Outcome:** One sentence stating what changes and why it matters.
- **Next action:** One concrete action or blocker, with a task link.

## Delivery

| Slice | Outcome / task | Depends on | State / evidence |
| --- | --- | --- | --- |
| 1 | Task link after creation | None | proposed |

Plans coordinate sequence and dependencies. Tasks hold acceptance criteria and
the reviewer brief; verification reports hold commands/results. Keep one state
table, update it in place, and link details instead of copying them. Put long
execution instructions in `plans/guides/` only when needed.

## Constraints and choices

Link relevant canonical context and accepted decisions. State non-goals and
material cross-task risks/dependencies. Include owner input only when required.
Delete empty prompts; aim for one page rather than filling every field.

## Completion and recovery

All linked tasks meet acceptance criteria with required evidence, context and
debt updated. State rollout/recovery or why no deployment is involved. Link the
final report and date, then move to `plans/completed/` and update incoming links
and indexes. Superseded plans go in `plans/superseded/`, without claiming their
unfinished scope is complete.
