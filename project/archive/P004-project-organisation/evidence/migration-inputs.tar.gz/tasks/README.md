# Task index

Read one task for its outcome, acceptance and reviewer brief. The
[roadmap](../plans/active/QUALITY_FIRST_HARNESS.md) owns sequencing and future
steps; reports own the actual commands/results. Task IDs and paths stay stable.

## Open work

| Task | State / limit | Evidence |
| --- | --- | --- |
| [016: Measurable reference UI quality](TASK-016-UI-QUALITY.md) | active; implementation verified, human baseline acceptance pending | [QH-13](../verification/QH-13.md) |

## Delivered locally

| Task | State / limit | Evidence |
| --- | --- | --- |
| [017: Make work and implementation easy to review](TASK-017-REVIEWABLE-WORK.md) | complete locally | [Report](../verification/REVIEWABLE_WORK.md) |
| [004: Current baseline and independent acceptance cases](TASK-004-QUALITY-BASELINE.md) | complete | [QH-01](../verification/QH-01.md) |
| [005: Independent application tests and harness self-tests](TASK-005-APPLICATION-TEST-ROUTING.md) | complete | [QH-02](../verification/QH-02.md) |
| [006: Consistent discovery and static-check precedence](TASK-006-DISCOVERY-AND-CHECK-PRECEDENCE.md) | complete | [QH-03](../verification/QH-03.md) |
| [007: Explicit release ownership preserves installation health](TASK-007-RELEASE-OWNERSHIP.md) | complete | [QH-04](../verification/QH-04.md) |
| [008: Run repaired core checks in pinned macOS CI](TASK-008-CORE-CI.md) | complete locally; remote execution unverified | [QH-05](../verification/QH-05.md) |
| [009: Resolve applicable controls and readiness](TASK-009-PROFILES-AND-DOCTOR.md) | complete locally | [QH-06](../verification/QH-06.md) |
| [010: Delegate formatting and enforce static checks](TASK-010-NATIVE-STATIC-TOOLS.md) | complete locally | [QH-07](../verification/QH-07.md) |
| [011: Bind complete verification to native evidence](TASK-011-VERIFICATION-EVIDENCE.md) | complete locally | [QH-08](../verification/QH-08.md) |
| [012: Executable security controls and isolated verification](TASK-012-SECURITY-AND-ISOLATION.md) | complete locally; security approval blocked by retained findings | [QH-09](../verification/QH-09.md) |
| [015: Prove production user and recovery journeys](TASK-015-USER-JOURNEYS.md) | complete locally | [QH-12](../verification/QH-12.md) |

## Historical partial reports

| Task | State / limit | Evidence |
| --- | --- | --- |
| [013: Production-buildable synthetic Next.js foundation](TASK-013-NEXTJS-REFERENCE-APP.md) | Historical partial; current journeys in QH-12 | [QH-10](../verification/QH-10.md) |
| [014: Persist authorized synthetic work-item edits](TASK-014-SECURE-PERSISTENCE.md) | Historical partial; current journeys in QH-12 | [QH-11](../verification/QH-11.md) |

[QH-12](../verification/QH-12.md) records renewed browser authorization and
current journey evidence for Steps 10–11. Their original partial reports and
unchecked historical criteria remain unchanged; they are not current browser
prohibitions. Human visual acceptance remains pending in TASK-016.

## Earlier foundation work

| Task | State / limit | Evidence |
| --- | --- | --- |
| [001: Adopt the three-layer harness structure](TASK-001-THREE-LAYER-STRUCTURE.md) | complete | [Phase 1](../verification/PHASE_1_THREE_LAYER_STRUCTURE.md) |
| [002: Add the versioned harness configuration contract](TASK-002-VERSIONED-CONFIGURATION.md) | complete | [Phase 2](../verification/PHASE_2_VERSIONED_CONFIGURATION.md) |
| [003: Establish an enforceable engineering baseline](TASK-003-ENGINEERING-STANDARDS.md) | complete | [Phase 3](../verification/PHASE_3_ENGINEERING_STANDARDS.md) |

Create new work from the [task template](TASK_TEMPLATE.md), using the next free
ID. Keep the brief short and link architecture, choices and evidence. Update
this index and the coordinating plan when state changes. A local pass does not
establish remote CI, security approval or human acceptance.
