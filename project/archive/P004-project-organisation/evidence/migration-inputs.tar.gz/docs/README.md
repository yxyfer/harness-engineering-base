# Reviewer entry

Understand the intent, implementation and risk before choosing which code to
inspect. This is a reading path for human judgment, not an approval record.

1. Read the selected task's outcome, acceptance criteria and reviewer brief in
   the [task index](../tasks/README.md). Challenge necessity and scope.
2. Follow the [harness architecture map](ARCHITECTURE.md) or the
   [reference-app map](../examples/nextjs-app/docs/ARCHITECTURE.md) to affected
   boundaries and source entry points. Read linked choices in
   [DECISIONS](DECISIONS.md); ask what operational context is missing.
3. Read the task's verification report and risk/recovery notes. Inspect the
   relevant diff, tests and callers; use the map to focus attention. Assess
   evidence limits, deployment impact and rollback before approval.

## Canonical context

| Question | Source |
| --- | --- |
| What outcome and scope? | [PRODUCT](PRODUCT.md) |
| Which components, flows and boundaries? | [ARCHITECTURE](ARCHITECTURE.md) |
| Which experience and interaction rules? | [DESIGN](DESIGN.md) |
| Which contracts, storage and provenance? | [DATA](DATA.md) |
| What do checks establish? | [QUALITY](QUALITY.md) |
| Which trust boundaries and approvals? | [SECURITY](SECURITY.md) |
| Why this durable choice? | [DECISIONS](DECISIONS.md) |

## Maintain the map

Keep the reviewer summary at the top of `ARCHITECTURE.md`: a small flow diagram,
linked component responsibilities, key choices and operational limits. For an
application, include one important user/data flow, authorization and external
boundaries, and failure/recovery. Use actual source paths, not a generated file
inventory. Mark planned or simulated components clearly.

Update affected flows and source/ADR links with the implementation. Tasks record
change-specific impact and evidence; canonical architecture describes the
current system. Scale detail to the change. A documentation pass does not prove
that the diagram is correct or that a human understands/accepts the design.
