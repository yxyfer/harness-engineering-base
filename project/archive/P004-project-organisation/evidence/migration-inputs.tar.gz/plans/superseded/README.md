# Superseded plans

| Record | Replacement / purpose |
| --- | --- |
| [Project Harness v2](PROJECT_HARNESS_V2.md) | [Quality-first roadmap](../active/QUALITY_FIRST_HARNESS.md); unfinished scope remains undelivered |
| [Quality-first early progress](quality-first-progress.md) | Historical observations through Step 09; current state lives in the roadmap |

Preserve decisions and evidence. Superseded means replaced, not completed.
